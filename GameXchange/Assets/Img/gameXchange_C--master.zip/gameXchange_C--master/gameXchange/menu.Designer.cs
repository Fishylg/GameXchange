﻿namespace gameXchange
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu));
            pictureBox1 = new PictureBox();
            buttonSair = new Button();
            buttonCadJog = new Button();
            buttonConJog = new Button();
            buttonCadAdm = new Button();
            buttonConAdm = new Button();
            labelMenu = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.FromArgb(43, 43, 43);
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(-31, -25);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(1121, 627);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // buttonSair
            // 
            buttonSair.BackColor = Color.FromArgb(43, 43, 43);
            buttonSair.Font = new Font("Verdana", 8.25F);
            buttonSair.ForeColor = Color.White;
            buttonSair.Location = new Point(934, 502);
            buttonSair.Name = "buttonSair";
            buttonSair.Size = new Size(137, 78);
            buttonSair.TabIndex = 1;
            buttonSair.Text = "Sair";
            buttonSair.UseVisualStyleBackColor = false;
            buttonSair.Click += button1_Click;
            // 
            // buttonCadJog
            // 
            buttonCadJog.BackColor = Color.FromArgb(205, 0, 3);
            buttonCadJog.Font = new Font("Verdana", 12F, FontStyle.Bold);
            buttonCadJog.ForeColor = Color.White;
            buttonCadJog.Location = new Point(168, 347);
            buttonCadJog.Name = "buttonCadJog";
            buttonCadJog.Size = new Size(183, 118);
            buttonCadJog.TabIndex = 2;
            buttonCadJog.Text = "Cadastrar jogos";
            buttonCadJog.UseVisualStyleBackColor = false;
            // 
            // buttonConJog
            // 
            buttonConJog.BackColor = Color.FromArgb(205, 0, 3);
            buttonConJog.Font = new Font("Verdana", 12F, FontStyle.Bold);
            buttonConJog.ForeColor = Color.White;
            buttonConJog.Location = new Point(362, 347);
            buttonConJog.Name = "buttonConJog";
            buttonConJog.Size = new Size(183, 118);
            buttonConJog.TabIndex = 3;
            buttonConJog.Text = "Consultar jogos";
            buttonConJog.UseVisualStyleBackColor = false;
            // 
            // buttonCadAdm
            // 
            buttonCadAdm.BackColor = Color.FromArgb(205, 0, 3);
            buttonCadAdm.Font = new Font("Verdana", 12F, FontStyle.Bold);
            buttonCadAdm.ForeColor = Color.White;
            buttonCadAdm.Location = new Point(555, 347);
            buttonCadAdm.Name = "buttonCadAdm";
            buttonCadAdm.Size = new Size(183, 118);
            buttonCadAdm.TabIndex = 4;
            buttonCadAdm.Text = "Cadastrar administradores";
            buttonCadAdm.UseVisualStyleBackColor = false;
            // 
            // buttonConAdm
            // 
            buttonConAdm.BackColor = Color.FromArgb(205, 0, 3);
            buttonConAdm.Font = new Font("Verdana", 12F, FontStyle.Bold);
            buttonConAdm.ForeColor = Color.White;
            buttonConAdm.Location = new Point(746, 347);
            buttonConAdm.Name = "buttonConAdm";
            buttonConAdm.Size = new Size(183, 118);
            buttonConAdm.TabIndex = 5;
            buttonConAdm.Text = "Consultar administradores";
            buttonConAdm.UseVisualStyleBackColor = false;
            // 
            // labelMenu
            // 
            labelMenu.AutoSize = true;
            labelMenu.BackColor = Color.FromArgb(43, 43, 43);
            labelMenu.Font = new Font("Verdana", 36F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelMenu.ForeColor = Color.White;
            labelMenu.Location = new Point(471, 135);
            labelMenu.Name = "labelMenu";
            labelMenu.Size = new Size(154, 59);
            labelMenu.TabIndex = 6;
            labelMenu.Text = "Menu";
            // 
            // Menu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1088, 599);
            Controls.Add(labelMenu);
            Controls.Add(buttonConAdm);
            Controls.Add(buttonCadAdm);
            Controls.Add(buttonConJog);
            Controls.Add(buttonCadJog);
            Controls.Add(buttonSair);
            Controls.Add(pictureBox1);
            Name = "Menu";
            Text = "Menu";
            Load += Menu_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Button buttonSair;
        private Button buttonCadJog;
        private Button buttonConJog;
        private Button buttonCadAdm;
        private Button buttonConAdm;
        private Label labelMenu;
    }
}