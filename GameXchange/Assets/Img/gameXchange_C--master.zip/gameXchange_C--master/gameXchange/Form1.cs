using System.Drawing.Drawing2D;
using MySql.Data.MySqlClient;

namespace gameXchange
{
    public partial class Inicio : Form
    {
        bool VerSenhaTxt = false;
        private string usuarioCorreto = "admin";
        private string senhaCorreta = "123456";
        public Inicio()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedDialog; //faz q n possa mexer e aumentar a tela

            this.MaximizeBox = false; //tira a op��o de maximizar a tela

            this.StartPosition = FormStartPosition.CenterScreen; //come�a no centro a tela

            //todos esses tr�s s�o obrigat�rios pra cada tela que for criada agora!!!!!!!!

            button1.FlatStyle = FlatStyle.Flat;
            button1.FlatAppearance.BorderSize = 0;
            textBoxEmail.BorderStyle = BorderStyle.None;
            textBoxSenha.BorderStyle = BorderStyle.None;

            //textBoxEmail.Text = "Endere�o de Email";
            //textBoxSenha.Text = "Senha";

            string conexaoString = "Server=localhost; Port=3306; Database=bd_gamexchange; Uid=root; Pwd=;";
        }

        private void inicio_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Menu form = new Menu();
            form.ShowDialog();
        }

        private void textBoxEmail_Enter(object sender, EventArgs e)
        {
            if (textBoxEmail.Text == "Endere�o de Email")
            {
                textBoxEmail.Text = "";
                textBoxEmail.ForeColor = Color.Black;
            }
        }

        private void textBoxEmail_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxEmail.Text))
            {
                textBoxEmail.Text = "Endere�o de Email";
                textBoxEmail.ForeColor = Color.Gray;
            }
        }
    }
}
