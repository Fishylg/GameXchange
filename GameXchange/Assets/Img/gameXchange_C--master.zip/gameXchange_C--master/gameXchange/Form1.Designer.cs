﻿namespace gameXchange
{
    partial class Inicio
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Inicio));
            button1 = new Button();
            textBoxEmail = new TextBox();
            textBoxSenha = new TextBox();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(205, 0, 3);
            button1.Font = new Font("Verdana", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.Snow;
            button1.Location = new Point(346, 311);
            button1.Name = "button1";
            button1.Size = new Size(181, 48);
            button1.TabIndex = 3;
            button1.Text = "Entrar";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // textBoxEmail
            // 
            textBoxEmail.BackColor = Color.FromArgb(43, 43, 43);
            textBoxEmail.Font = new Font("Verdana", 8.25F, FontStyle.Bold);
            textBoxEmail.ForeColor = SystemColors.ButtonShadow;
            textBoxEmail.Location = new Point(355, 226);
            textBoxEmail.Name = "textBoxEmail";
            textBoxEmail.Size = new Size(160, 21);
            textBoxEmail.TabIndex = 4;
            textBoxEmail.Text = "Endereço de Email";
            // 
            // textBoxSenha
            // 
            textBoxSenha.BackColor = Color.FromArgb(43, 43, 43);
            textBoxSenha.Font = new Font("Verdana", 8.25F, FontStyle.Bold);
            textBoxSenha.ForeColor = SystemColors.ButtonShadow;
            textBoxSenha.Location = new Point(355, 268);
            textBoxSenha.Name = "textBoxSenha";
            textBoxSenha.PasswordChar = '*';
            textBoxSenha.Size = new Size(146, 21);
            textBoxSenha.TabIndex = 5;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(503, 269);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(18, 19);
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // Inicio
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(884, 461);
            Controls.Add(pictureBox1);
            Controls.Add(textBoxSenha);
            Controls.Add(textBoxEmail);
            Controls.Add(button1);
            Name = "Inicio";
            Text = "gameXchange";
            Load += inicio_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button button1;
        private TextBox textBoxEmail;
        private TextBox textBoxSenha;
        private PictureBox pictureBox1;
    }
}
