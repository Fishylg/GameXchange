﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gameXchange
{
    public partial class Menu : Form
    {
        public Menu()
        {

            InitializeComponent();

            this.ClientSize = new System.Drawing.Size(1089, 596); //faz a tela sempre ter esse tamanho, obrigatório pra cada Form q criar

            this.FormBorderStyle = FormBorderStyle.FixedDialog; //faz q n possa mexer e aumentar a tela

            this.MaximizeBox = false; //tira a opção de maximizar a tela

            this.StartPosition = FormStartPosition.CenterScreen; //começa no centro a tela

            //todos esses três são obrigatórios pra cada tela que for criada agora!!!!!!!!

            buttonSair.FlatStyle = FlatStyle.Flat;
            buttonSair.FlatAppearance.BorderSize = 0;

            pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;


        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Menu_Load(object sender, EventArgs e)
        {

        }
    }
}
